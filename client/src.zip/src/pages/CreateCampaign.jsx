import React from 'react'

const CreateCampaign = () => {
  return (
    <div>CreateCampaign</div>
  )
}

export default CreateCampaign