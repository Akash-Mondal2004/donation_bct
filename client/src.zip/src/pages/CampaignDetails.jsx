import React from 'react'

const CampaignDetails = () => {
  return (
    <div>CampaignDetails</div>
  )
}
export default CampaignDetails;